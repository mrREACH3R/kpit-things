
#include "inventory.h"
#include <stdexcept>
 

Inventory::Inventory() : balance_stock(30) {
    if (balance_stock < 20)
        balance_stock = 20;
}
 
Inventory::Inventory(std::string description, int stock, int code)
    : description_of_product(description), balance_stock(stock), productcode(code) {
    if (balance_stock < 20)
        balance_stock = 20;
}
 

void Inventory::purchaseProduct(int quantity) {
    balance_stock += quantity;
    std::cout << "After purchase stock: " << balance_stock << std::endl;
}
 
void Inventory::saleProduct(int quantity) {
    if (balance_stock - quantity < 20) {
        throw std::runtime_error("Stock is low");
    } else {
        balance_stock -= quantity;
        std::cout << "After sale stock: " << balance_stock << std::endl;
    }
}
 
void Inventory::find(Inventory arr[], int size, int productCode) {
    bool found = false;
    for (int i = 0; i < size; i++) {
        if (arr[i].productcode == productCode) {
            found = true;
            std::cout << "Product is: " << arr[i].description_of_product << std::endl;
            break;
        }
    }
    if (!found)
        throw std::runtime_error("not in the list");
}



void displayShoppingProducts(Inventory arr[], int size)
{
 std::cout << "Shopping Products............." << std::endl;
    for (int i = 0; i < size;i++) {
        if (arr[i].getProductcode()==0) {
            std::cout << "Description: " << arr[i].descriptionOfProduct() << arr[i].balanceStock() ;
        }
    }
}
