
 
#ifndef INVENTORY_H
#define INVENTORY_H

#include <iostream>
#include <string>
 
 
class Inventory {
private:
    std::string description_of_product;
    int balance_stock;
    int productcode;
 
public:
    enum ProductType { Accessories, Shopping };
 
    
    Inventory();
    Inventory(std::string description, int stock, int code);
 
    
    void purchaseProduct(int quantity);
    void saleProduct(int quantity);
    static void find(Inventory arr[], int size, int productCode);

    int getProductcode() const { return productcode; }
    void setProductcode(int productcode_) { productcode = productcode_; }

    int balanceStock() const { return balance_stock; }
    void setBalanceStock(int balanceStock) { balance_stock = balanceStock; }

    std::string descriptionOfProduct() const { return description_of_product; }
    void setDescriptionOfProduct(const std::string &descriptionOfProduct) { description_of_product = descriptionOfProduct; }

    
    
};

 void displayShoppingProducts(Inventory arr[], int size);

#endif // INVENTORY_H
