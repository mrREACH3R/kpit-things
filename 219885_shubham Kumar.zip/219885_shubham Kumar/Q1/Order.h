#ifndef ORDER_H
#define ORDER_H

#include<iostream>
enum orderType{MARKET,LIMIT,STOP};
class Order
{
private:
    /* data */
int order_id;
double order_value;
double discount;
static int count;
enum orderType otype;

public:
    Order();
    Order(int,double,double,enum orderType);
    void accept();
    void display();
    // double maxdiscount();
    // double calavgdiscount();

    static void printcount();
    


    ~Order();

    int orderId() const { return order_id; }
    void setOrderId(int orderId) { order_id = orderId; }

    double orderValue() const { return order_value; }
    void setOrderValue(double orderValue) { order_value = orderValue; }

    double getDiscount() const { return discount; }
    void setDiscount(double discount_) { discount = discount_; }

    enum orderType getOtype() const { return otype; }
    void setOtype(const enum orderType &otype_) { otype = otype_; }
};



#endif // ORDER_H
