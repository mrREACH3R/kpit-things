#include"Order.h"

int main(){
Order order[3];

for(int i=0;i<3;i++){
  order[i].accept();
}
double maxDis=order[0].getDiscount();
for(int i=0;i<3;i++){
    
    if( order[i].getDiscount()>maxDis){
        maxDis=order[i].getDiscount();
        
    }
   
}
   std::cout<<"Max discount :"<<maxDis;

std::cout<<"\nEnter the order id :";

int n;
std::cin>>n;
bool flag=false;
for (int i = 0; i < 3; i++)
{
   if(n==order[i].orderId()){
    // std::cout<<"Value of order is :"<<order[i].orderValue();
    // std::cout<<"\nType of order is :"<<order[i].getOtype();
    order[i].display();
    flag=true;

   }

}
if(!flag){
  std::cout<<"User Not found !!";
}

   double avg=0;
   double sum=0;
for(int i=0;i<3;i++){
   
  
   sum+=order[i].getDiscount();
   

}
avg=sum/3;
   std::cout<<"\nAverage dis :"<<avg;

std::cout<<"\n No of order placed :";
order->printcount();

return 0;

}

