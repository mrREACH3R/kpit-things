#include "Order.h"
int Order::count=0;
Order::Order():order_id(1),order_value(100),discount(10),otype(MARKET)
{
    count++;
}

Order::Order(int id, double value, double disct,orderType otp)
:order_id(id),order_value(value),discount(disct),otype(otp)
{
    count++;
}

void Order::accept()
{

    std::cout<<"Enter order id:";
    std::cin>>order_id;
    std::cout<<"Enter order value:";
    std::cin>>order_value;
    std::cout<<"Enter order discount:";
    std::cin>>discount;
    int t;
    std::cout<<"Enter 0 for Market ,1 for Limit, 2 for stop";
    std::cin>>t;
    switch(t)
    {   
        case 0: otype=orderType::LIMIT;break;
        case 1: otype=orderType::LIMIT;break;
        case 3: otype=orderType::STOP;

    }
    
    
    
        
}

void Order::display()
{

std::cout<<"\nOrder Id :"<<order_id;
std::cout<<"\nOrder Value :"<<order_value;
std::cout<<"\nOrder Discount :\n"<<discount;

switch (otype)
{
case 0:
   std::cout<<"Saving";
    break;
    case 1:
   std::cout<<"Limit ";
    break;
    case 2:
   std::cout<<"Stop";
    break;

default:
std::cout<<"Not found ";
    break;
}


}

 void Order::printcount()
{
 std::cout<<count;
}



Order::~Order()
{
}
