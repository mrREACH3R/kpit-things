#include "Onlineexam.h"

onlineexam::onlineexam()
{
   ExamType(METTL); 
}

onlineexam::onlineexam(int examcode ,Date dt,ExamType etype):Exam(examcode,dt)
{
  examPlatform=etype;
}

onlineexam::~onlineexam()
{
}


std::istream &operator>>(std::istream &is, onlineexam &oexam)
{
    is>>static_cast<Exam&>(oexam);
    int t;
    std::cout<<"Enter 0 for synap 1 for Metal";
    std::cin>>t;
    switch(t)
    {   
        case 0: oexam.METTL;

        case 1: oexam.SYNAP;

    }
}
std::ostream &operator<<(std::ostream &os, onlineexam &oexam)
{
    os<<static_cast<Exam&>(oexam);

    // switch (oexam.examPlatform)
    // {
    // case 0:

    //     break;
    
    // default:
    //     break;
    // }
    os<<"Exam platform :"<<oexam.examPlatform;

}
