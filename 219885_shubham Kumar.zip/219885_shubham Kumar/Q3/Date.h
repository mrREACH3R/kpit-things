#ifndef DATE_H
#define DATE_H

#include<iostream>
#include<iostream>

class Date
{
public:
    /* data */
    int day;
    int month;
    int year;
    bool valid;


    Date();
    
    Date(int,int,int);
    
    bool accept();
    int getDay() const { return day; }
    void setDay(int day_) { day = day_; }

    int getMonth() const { return month; }
    void setMonth(int month_) { month = month_; }

    int getYear() const { return year; }
    void setYear(int year_) { year = year_; }

    friend std::ostream& operator<<(std::ostream &os,const Date &dobj);

    
   friend std::istream& operator>>(std::istream &is,Date &idobj);
};

#endif // DATE_H
