#ifndef ADDRESS_H
#define ADDRESS_H

#include<iostream>
#include<cstring>
class Addres
{
private:
    /* data */
    std::string city;
    int pincode;
    

public:
    Addres();
    Addres(int,std::string);
   
    void display();
    std::string getCity() const { return city; }
    void setCity(const std::string &city_) { city = city_; }
    friend std::ostream& operator<<(std::ostream &os,Addres &aobj);
    friend std::istream& operator>>(std::istream &is,Addres &idobj);
    
};

#endif // ADDRESS_H


