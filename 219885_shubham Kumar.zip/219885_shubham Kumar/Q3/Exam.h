#ifndef EXAM_H
#define EXAM_H

#include"Date.h"

class Exam
{
public:
    int exam_code;
    Date exam_date;

    Exam(int,Date);
    Exam();
    ~Exam();
    friend std::ostream& operator<<(std::ostream &os,Exam &eobj);
    friend std::istream& operator>>(std::istream &is,Exam &eobj);
};

#endif // EXAM_H
