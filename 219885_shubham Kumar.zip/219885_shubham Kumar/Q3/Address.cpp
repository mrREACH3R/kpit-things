#include "Address.h"

Addres::Addres():pincode(1),city("pune")
{

}

Addres::Addres(int pin, std::string cit):pincode(pin),city(cit)
{
}

std::ostream &operator<<(std::ostream &os, Addres &aobj)
{
    os<<"Pin code :"<<aobj.pincode;
    os<<"\nCity :"<<aobj.city;
    
    
}

std::istream &operator>>(std::istream &is, Addres &idobj)
{
    std::cout<<"Enter pin Code :";
    is>>idobj.pincode;
    std::cout<<"Enter City :";
    is>>idobj.city;

}


