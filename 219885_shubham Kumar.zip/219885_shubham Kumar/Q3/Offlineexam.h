#ifndef OFFLINEEXAM_H
#define OFFLINEEXAM_H

#include"Exam.h"
#include"Address.h"
class Offlineexam:public Exam
{
private:
    Addres examlocation;
    
public:
    Offlineexam(int,Date,Addres);
    Offlineexam();
    ~Offlineexam();
    Addres getExamlocation() const { return examlocation; }
    void setExamlocation(const Addres &examlocation_) { examlocation = examlocation_; }
    friend std::ostream& operator<<(std::ostream &os,Offlineexam &oexam);
    friend std::istream& operator>>(std::istream &is,Offlineexam &oexam);

};

#endif // OFFLINEEXAM_H
