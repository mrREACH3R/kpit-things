#include "onlineexam.h"
#include "Offlineexam.h"


int main()
{

    onlineexam *oarr[3];

    for (int i = 0; i < 3; ++i)
    {
        oarr[i] = new onlineexam;
        std::cin >> *oarr[i];
    }
     for (int i = 0; i < 3; ++i)
    {
        
        std::cout << *oarr[i];
    }

    Offlineexam off[3];
    for(int i=0;i<3;i++){
        std::cin>>off[i];
    }
    
    std::cout<<"Enter exam Citry that you want to show";
    std:: string n;
    std::cin>>n;
    Exam e[3];
    bool flag=false;
    for(int i=0;i<3;i++){
        if (n==off[i].getExamlocation().getCity())
        {
            std::cout<<off[i];
            flag=true;

        }
        
        
    }

   if (!false){
        std::cout<<"not found";
    }


    return 0;
}



