#include "Exam.h"

Exam::Exam(int examcode, Date dt)
{
  exam_code=examcode;
  exam_date=dt;
}

Exam::Exam()
{
exam_code=101;

}
Exam::~Exam()
{
}
std::ostream& operator<<(std::ostream &os,Exam &eobj){
        os<<"Exam Code :"<<eobj.exam_code;
        os<<"Date :"<<eobj.exam_date;

    }


    std::istream &operator>>(std::istream &is, Exam &eobj)
    {
       std::cout<<"Enter Exam code :";
       is>>eobj.exam_code;
       std::cout<<"Exam Date :";
       is>>eobj.exam_date;

       
    }





