#include "Offlineexam.h"

Offlineexam::Offlineexam(int examcode ,Date dt,Addres adrs) :Exam(examcode,dt)
{
    examlocation=adrs;
}

Offlineexam::Offlineexam()
{
}



Offlineexam::~Offlineexam()
{
}

std::ostream &operator<<(std::ostream &os, Offlineexam &oexam)
{   
    os<<static_cast<Exam&>(oexam);
    os<<"Exam Location :"<<oexam;
}

std::istream &operator>>(std::istream &is, Offlineexam &oexam)
{
    is>>static_cast<Exam&>(oexam);
    std::cout<<"Enter Exam Location :";
    is>>oexam.examlocation;
}

