#include "Date.h"
Date::Date() : day(1), month(1), year(2022), valid(false)

{}
 
Date::Date(int day, int month, int year) : day(day), month(month), year(year){
    // valid = accept();
}
 
// bool Date::accept() {
//     std::cout << "Enter date (day month year): ";
//     std::cin >> day >> month >> year;
 
//     if(year < 1 || year > 9999)
//     {
//         std::cout << "Invalid year" << std::endl;
//         return false;
//     }
 
//     if(month < 1 || month > 12)
//     {
//         std::cout << "Invalid month" << std::endl;
//         return false;
//     }
 
//     int daysinmonth[13] = {0, 31, 28, 31, 30, 31, 20, 31, 31, 30, 31, 30, 31};
//     if(day < 1 || day > daysinmonth[month]) {
//         std::cout << "Invalid day" << std::endl;
//         return false;
//     }
//     return true;
// }
 
// std::ostream& operator<<(std::ostream& os, const Date& date) {
//     if (date.valid) {
//         os << date.day << "/" << date.month << "/" << date.year;
//     } else {
//         os << "Invalid Date";
//     }
//     return os;
// }



std::istream &operator>>(std::istream &is, Date &idobj)
{
    is>>idobj.day;
    is>>idobj.month;
    is>>idobj.year;
}
std::ostream& operator<<(std::ostream &os,const Date &dobj){
os<<"day :"<<dobj.day<<"month :"<<dobj.month<<"year :"<<dobj.year;
}