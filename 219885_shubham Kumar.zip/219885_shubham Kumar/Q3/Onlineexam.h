
#ifndef ONLINEEXAM_H
#define ONLINEEXAM_H

#include "Exam.h"

class onlineexam : public Exam
{
public:
    /* data */

    enum ExamType
    {
        SYNAP,
        METTL
    };
    ExamType examPlatform;

    onlineexam();
    onlineexam(int,Date, ExamType);
    ~onlineexam();
    friend std::ostream& operator<<(std::ostream &os,onlineexam &oexam);
    friend std::istream& operator>>(std::istream &is,onlineexam &oexam);
    
};

#endif // ONLINEEXAM_H
